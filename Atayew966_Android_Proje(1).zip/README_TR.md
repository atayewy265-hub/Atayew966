# Atayew 966

Android Studio/Gradle projesi. APK, GitHub Actions ile oluşturulabilir.

## Telefonda kullanım
1. Bu projedeki dosyaları GitHub deposunun ana dizinine yükleyin.
2. GitHub deposunda Actions sekmesine girin.
3. "Android APK oluştur" iş akışını seçip Run workflow düğmesine dokunun.
4. İşlem bitince oluşan çalıştırmayı açın; Artifacts bölümünden `Atayew966-APK` dosyasını indirin.

## Güvenlik notu
Bu bir başlangıç prototipidir; güvenlik denetiminden geçmemiştir. Önemli hesapların gerçek şifrelerini saklamadan önce uzman güvenlik incelemesi yaptırın. Ana şifrenizi unutursanız kayıtları kurtaramazsınız.
