plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.atayew966.vault"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.atayew966.vault"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
