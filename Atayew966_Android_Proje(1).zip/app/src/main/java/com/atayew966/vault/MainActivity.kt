package com.atayew966.vault

import android.app.Activity
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import android.util.Base64

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("vault", MODE_PRIVATE) }
    private val random = SecureRandom()
    private lateinit var list: LinearLayout
    private lateinit var master: EditText
    private var key: ByteArray? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(22, 28, 22, 18)
        }
        root.addView(TextView(this).apply {
            text = "Atayew 966"; textSize = 28f; gravity = Gravity.CENTER
        })
        master = EditText(this).apply {
            hint = "Ana şifre"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        root.addView(master)
        root.addView(Button(this).apply {
            text = "Kasayı aç"
            setOnClickListener {
                if (master.text.length < 8) { toast("Ana şifre en az 8 karakter olmalı"); return@setOnClickListener }
                key = derive(master.text.toString(), salt())
                showVault(root)
            }
        })
        setContentView(root)
    }

    private fun showVault(root: LinearLayout) {
        root.removeAllViews()
        root.addView(TextView(this).apply { text = "Atayew 966 — Şifre Kasası"; textSize = 23f })
        root.addView(Button(this).apply { text = "Yeni kayıt ekle"; setOnClickListener { addEntry() } })
        root.addView(Button(this).apply { text = "Güçlü şifre üret"; setOnClickListener {
            val chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#%*-_"
            val pass = (1..20).map { chars[random.nextInt(chars.length)] }.joinToString("")
            copy(pass); toast("Şifre panoya kopyalandı: $pass")
        }})
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(list) },
            LinearLayout.LayoutParams(-1, 0, 1f))
        refresh()
    }

    private fun addEntry() {
        val title = EditText(this).apply { hint = "Başlık / site" }
        val user = EditText(this).apply { hint = "Kullanıcı adı" }
        val pass = EditText(this).apply { hint = "Şifre" }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18,8,18,8) }
        box.addView(title); box.addView(user); box.addView(pass)
        AlertDialogBuilder(this, box) {
            val raw = listOf(title.text.toString(), user.text.toString(), pass.text.toString()).joinToString("\n")
            if (title.text.isNotBlank() && pass.text.isNotBlank()) {
                val entries = load().toMutableList(); entries.add(raw); save(entries); refresh()
            }
        }
    }

    private fun refresh() {
        list.removeAllViews()
        load().forEachIndexed { i, raw ->
            val parts = raw.split("\n")
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8,12,8,12) }
            row.addView(TextView(this).apply { text = parts.getOrElse(0){""} + "  •  " + parts.getOrElse(1){""}; textSize = 17f })
            row.addView(Button(this).apply { text = "Şifreyi kopyala"; setOnClickListener { copy(parts.getOrElse(2){""}); toast("Kopyalandı") } })
            row.addView(Button(this).apply { text = "Sil"; setOnClickListener {
                val entries = load().toMutableList(); entries.removeAt(i); save(entries); refresh()
            }})
            list.addView(row)
        }
    }

    private fun salt(): ByteArray {
        val old = prefs.getString("salt", null)
        if (old != null) return Base64.decode(old, Base64.DEFAULT)
        val b = ByteArray(16); random.nextBytes(b)
        prefs.edit().putString("salt", Base64.encodeToString(b, Base64.NO_WRAP)).apply()
        return b
    }
    private fun derive(password: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, 600000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }
    private fun encrypt(data: String): String {
        val iv = ByteArray(12); random.nextBytes(iv)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key!!, "AES"), GCMParameterSpec(128, iv))
        return Base64.encodeToString(iv + cipher.doFinal(data.toByteArray()), Base64.NO_WRAP)
    }
    private fun decrypt(value: String): String = try {
        val bytes = Base64.decode(value, Base64.DEFAULT)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key!!, "AES"), GCMParameterSpec(128, bytes.copyOfRange(0,12)))
        String(cipher.doFinal(bytes.copyOfRange(12, bytes.size)))
    } catch (_: Exception) { "" }
    private fun load(): List<String> = prefs.getString("data", "")!!.split("\u001e").filter { it.isNotBlank() }.map { decrypt(it) }.filter { it.isNotBlank() }
    private fun save(items: List<String>) {
        prefs.edit().putString("data", items.joinToString("\u001e") { encrypt(it) }).apply()
    }
    private fun copy(s: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("password", s))
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun AlertDialogBuilder(ctx: Context, view: android.view.View, save: () -> Unit) {
        android.app.AlertDialog.Builder(ctx).setTitle("Kayıt").setView(view)
            .setPositiveButton("Kaydet") { _, _ -> save() }.setNegativeButton("İptal", null).show()
    }
}
